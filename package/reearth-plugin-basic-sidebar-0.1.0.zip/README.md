# reearth-plugin-toolbox
## Toolbox - Sidebar

- Just a simple sidebar to show some UI elements.